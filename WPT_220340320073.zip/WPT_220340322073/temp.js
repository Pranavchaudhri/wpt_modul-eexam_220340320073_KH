const express=require('express');
const app=express();
app.use(express.static('sf'));
let connection={
host:"localhost",
user:"root",
password:"cdac",
database:"test1",
port:3306,
}

const mysql=require('mysql2');
const con=mysql.createConnection(connection);

console.log("before get the value");
app.get("/getbook",(req,res)=>{
	console.log("after getting")
	let id=req.query.id;
	console.log(id);
	
	let ouput={status:false,details:{id:0,name:'',price:0}}
	con.query('select*from book where bookid=?',[id],(error,rows)=>)
	if(error){
		console.log('error aya'+toString(error))
	}else{if(rows.length>0){
console.log('success');
output.status=true;
output.detail.id=rows[0].bookid;
output.detail.name=rows[0].bookname;
output.detail.price=rows[0].price;
	}else{
		console.log("update success")
	}}
	res.send(output);
});
app.listen(5500,function(){
console.log('server listening at 8081');
});


